#-------------------------------------------------------------------------#
#                       Tailored Metropolis-Hastings Algorithm
#                             Author: Keegan Skeate
#                       Copyright 2016. All Rights Reserved.
#-------------------------------------------------------------------------#
import numpy as np
from math import *
#-------------------------------------------------------------------------#
#                      Tailored Metrolpolis-Hastings Algorithm            #
#-------------------------------------------------------------------------#
def MV_t_pdf(x,mu,Sigma,df):
    """
    Inputs:
        x - kx1 Random variables
        mu - kx1 Mean values
        Sigma - kxk Scale matrix
        df - Degrees of freedom
    Returns: The density of the given element.
    """
    p = len(x)
    numerator = gamma(1.*(p+df)/2)
    denomenator = (gamma(1.*df/2)*pow(df*pi,1.*p/2)*
                  pow(np.linalg.det(Sigma),1./2)*
                  pow(1+(1./df)*
                  np.dot(np.dot((x-mu),np.linalg.inv(Sigma)),(x-mu)),
                  1.*(p+df)/2))
    density = 1. * numerator/denomenator
    return density
    
def MV_t_random_var(mu, Sigma, df):
    """
    Inputs:
        mu - kx1 Means of the random variables
        Sigma - kxk Scale matrix
        df - Degrees of freedom
    Returns: n Independent draws from a MV-t distribution.
    """
    mu = np.asarray(mu)
    p = len(mu)
    u = np.random.chisquare(df)
    y = np.random.multivariate_normal(np.zeros(p),Sigma)
    return mu + y*np.sqrt(df/u)
    
def Tailored_MH(f,prior,beta0,Sigma0,y,X,i,df):
    """
    Inputs:
        f - a likelihood function.
        prior - Your Bayesian prior.
        beta0 - kx1 initial values
        Sigma0 - kxk initial values
        y - nx1 observations of the dependent variable.
        X - nxk observations of the independent variables.
        i - iterations.
        df - degrees of freedom.
    Returns:
        i draws of beta from the posterior, and the acceptance rate.
    """
    beta = np.zeros((i,len(beta0)))
    beta[0]=beta0
    acceptance = np.zeros(i)
    for i in range(i):
        beta_star = MV_t_random_var(beta0, Sigma0, df)
        Numerator = f(beta_star,y,X)*prior(beta_star,beta0,Sigma0)*\
                    MV_t_pdf(beta[i-1],beta0,Sigma0,df)
        Denomenator = f(beta[i-1],y,X)*prior(beta[i-1],beta0,Sigma0)*\
                    MV_t_pdf(beta_star,beta0,Sigma0,df)
        alpha = min(1.,1.*Numerator/Denomenator)
        acceptance[i] = np.random.binomial(1, alpha)
        if acceptance[i]==1:
            beta[i] = beta_star
        else:
            beta[i]=beta[i-1]
    acceptance_rate = np.mean(acceptance)
    return beta, acceptance_rate
#-------------------------------------------------------------------------#
#              Example Tailored-MH routine fitting a Logit model.
#-------------------------------------------------------------------------#
import pandas as pd    
import scipy.stats as ss
import pylab as py

def beta_prior(beta,mu,sigma):
    """ Multivariate Normal Prior """
    return ss.multivariate_normal.pdf(beta, mean=mu, cov=sigma)

def logit_cdf(z):
    return 1/(1+np.exp(-z))
    
def logit_pdf(z):
    return np.exp(-z)/(1+np.exp(-z))**2
    
def logit_score(beta,y,X):
    N = len(y)
    ll_score = 0.0
    for i in range(N):
        XB = np.dot(X[[i],:],beta)
        F_XB = logit_cdf(XB)
        ll_score += (y[i]-F_XB)*X[[i],:]
    return ll_score
    
def logit_hessian(beta,y,X):
    N = len(y)
    ll_hessian = 0.0
    for i in range(N):
        XB = np.dot(X[[i],:],beta)
        f_XB = logit_pdf(XB)
        ll_hessian += -(f_XB*np.dot(X[[i],:].T,X[[i],:]))
    return ll_hessian
    
def newton_method(gradient,hessian,beta0,y,X,tol=1e-6,maxIter=25):
    beta_old = beta0   
    for i in range(maxIter):
        beta_new = beta_old - np.dot(np.linalg.inv(hessian(beta_old,y,X)),
                                     gradient(beta_old,y,X).T)
        if (py.norm(beta_new-beta_old)<tol):
            break
        beta_old = beta_new
    return beta_new

def logit_LL(beta,y,X):
    """ Logit Log-Likelihood """
    N = len(y)
    ll = 0.0
    for i in range(N):
        XB = np.dot(X[[i],:],beta)
        q_i = 2*y[i]-1
        ll += log(logit_cdf(q_i*XB))
    return ll
    
def logit_marginal_effect(beta,y,X):
    """ Marginal Effect from a change in x at x_n """
    XB = np.dot(X,beta)
    return beta*logit_cdf(XB)*(1-logit_cdf(XB))
    
def avg_marginal_effect(beta,y,X):
    """ Average Marginal Effect of the sample """
    effect = 0.0
    for i in range(len(y)):
        effect += logit_marginal_effect(beta,y[i],X[[i],:])
    return effect/len(y)
#-------------------------------------------------------------------------#   
#                                Execution
#-------------------------------------------------------------------------#
data = pd.read_excel('Data_MH.xlsx', header=None)
y = data[0].values
X = data[[1,2,3]].values
#  Tailored Metropolis Hastings
i = 10000
virgin_prior = np.zeros((3,1))
logit_MLE = newton_method(logit_score,logit_hessian,virgin_prior,y,X)
logit_cov_MLE = -np.linalg.inv(logit_hessian(logit_MLE,y,X))
beta0 = np.hstack(logit_MLE)
Sigma0 = logit_cov_MLE
beta_distribution, rate = Tailored_MH(logit_LL,beta_prior,
                                      beta0,Sigma0,y,X,
                                      i,df=9)
print "rate\n",rate
# 10% Burn-In
beta = beta_distribution[0.1*i:]
# Posterior means and standard deviations of average marginal effects
avg_marginal_effects = np.zeros((i,len(beta0)))
for i in range(i):
    avg_marginal_effects[i] = avg_marginal_effect(beta_distribution[i],y,X)
posterior_mean_AME = mean(avg_marginal_effects, axis=0)
posterior_std_AME = std(avg_marginal_effects, axis=0)
print "posterior_mean_AME\n",posterior_mean_AME
print "posterior_std_AME\n",posterior_std_AME